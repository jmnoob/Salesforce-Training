import { LightningElement } from 'lwc';

export default class Billsforadmin extends LightningElement {}